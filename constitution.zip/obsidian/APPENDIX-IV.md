THE CONSTITUTION (EIGHTY-SIXTH AMENDMENT)

ACT, 2002

[12th December, 2002]

An Act further to amend the Constitution of India.

BE it enacted by Parliament in the Fifty-third year of the Republic of India as follows:-

1. Short title and commencement

(1) This Act may be called the Constitution (Eighty-sixth Amendment) Act, 2002.

(2) It shall come into force on such date [^1] as the Central Government may, by notification in the Official Gazette, appoint.

2. Insertion of new article [[21A]].—After article 21 of the Constitution, the following article shall be inserted, namely:--

“21A. Right to education.—The State shall provide free and compulsory education to all children of the age of six to fourteen years in such manner as the State may, by law, determine.”.

3. Substitution of new article for article [[45]].—For article 45 of the Constitution, the following article shall be substituted, namely:--

“45. Provision for early childhood care and education to children below the age of six years.—The State shall endeavour to provide early childhood care and education for all children until they complete the age of six years.”.

1. Amendment of article [[51A]].—In article 51A of the Constitution, after clause (j),

the following clause shall be added, namely:--

“(k) who is a parent or guardian to provide opportunities for education to his child or, as the case may be, ward between the ago of six and fourteen years.”.

[^1]: Date yet to be notified.