[[1]]. Name and territory of the Union.
[[2]]. Admission or establishment of new States.
[[2A]]. [Sikkim to be associated with the Union.] Rep. by the Constitution (Thirty- sixth Amendment) Act, 1975, s. 5 (w.e.f. 26-4-1975).
[[3]]. Formation of new States and alteration of areas, boundaries or names of existing States
[[4]]. Laws made under articles 2 and 3 to provide for the amendment of the First and the Fourth Schedules and supplemental, incidental and consequential matters