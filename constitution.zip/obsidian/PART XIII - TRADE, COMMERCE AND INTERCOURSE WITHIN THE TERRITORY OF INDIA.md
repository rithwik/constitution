[[301]]. Freedom of trade, commerce and intercourse
[[302]]. Power of Parliament to impose restrictions on trade, commerce and intercourse
[[303]]. Restrictions on the legislative powers of the Union and of the States with regard to trade and commerce
[[304]]. Restrictions on trade, commerce and intercourse among States
[[305]]. Saving of existing laws and laws providing for State monopolies
[[306]]. [Power of certain States in Part B of the First Schedule to impose restrictions on trade and commerce.] Rep. by the Constitution (Seventh Amendment) Act, 1956, s. 29 and Sch.
[[307]]. Appointment of authority for carrying out the purposes of articles 301 to 304