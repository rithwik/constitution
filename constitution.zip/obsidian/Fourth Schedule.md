FOURTH SCHEDULE


Articles [[4]](1) and [[80]](2)


Allocation of seats in the Council of States

To each State or Union territory specified in the first column of the following table, there shall be allotted the number of seats specified in the second column thereof opposite to that State or that Union territory, as the case may be.

1. Andhra Pradesh	18
2. Assam	7
3 Bihar	16
4 Jharkhand	6
5 Goa	1
6 Gujarat	11
7 Haryana	5
8 Kerala	9
9 Madhya Pradesh	11
10 Chhattisgarh	5
11 Tamil Nadu	18
12 Maharashtra	19
13 Karnataka	12
14 Orissa	10
15 Punjab	7
16 Rajasthan	10
17 Uttar Pradesh	31
18 Uttaranchal	3
19 West Bengal	16
20 Jammu and Kashmir	4
21 Nagaland	1
22 Himachal Pradesh	3
23 Manipur	1
24 Tripura	1
25 Meghalaya	1
26 Sikkim	1
27 Mizoram	1
28 Arunachal Pradesh	1
29 Delhi	3
30 Pondicherry	1
Total 233