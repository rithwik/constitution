[[243]]. Definitions
[[243A]]. Gram Sabha
[[243B]]. Constitution of Panchayats
[[243C]]. Composition of Panchayats
[[243D]]. Reservation of seats
[[243E]]. Duration of Panchayats, etc.
[[243F]]. Disqualifications for membership.
[[243G]]. Powers, authority and responsibilities of Panchayats
[[243H]]. Powers to impose taxes by, and Funds of, the Panchayats
[[243-I]]. Constitution of Finance Commission to review financial position
[[243J]]. Audit of accounts of Panchayats
[[243K]]. Elections to the Panchayats
[[243L]]. Application to Union territories
[[243M]]. Part not to apply to certain areas
[[243N]]. Continuance of existing laws and Panchayats
[[243-O]]. Bar to interference by courts in electoral matters