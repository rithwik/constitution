ELEVENTH SCHEDULE
Article [[243G]]

1. Agriculture, including agricultural extension.

2. Land improvement, implementation of land reforms, land consolidation and soil conservation.

3. Minor irrigation, water management and watershed development.

4. Animal husbandry, dairying and poultry.

5. Fisheries.

6. Social forestry and farm forestry.

7. Minor forest produce.

8. Small scale industries, including food processing industries.

9. Khadi, village and cottage industries.

10. Rural housing.

11. Drinking water.

12. Fuel and fodder.

13. Roads, culverts, bridges, ferries, waterways and other means of communication.

14. Rural electrification, including distribution of electricity.

15. Non-conventional energy sources.

16. Poverty alleviation programme.

17. Education, including primary and secondary schools.

18. Technical training and vocational education.

19. Adult and non-formal education.

20. Libraries.

21. Cultural activities.

22. Markets and fairs.

23. Health and sanitation, including hospitals, primary health centres and dispensaries.

24. Family welfare.

25. Women and child development.

26. Social welfare, including welfare of the handicapped and mentally retarded.

27. Welfare of the weaker sections, and in particular, of the Scheduled Castes and the Scheduled Tribes.

28. Public distribution system.

29. Maintenance of community assets.