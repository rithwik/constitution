[[31A]]. Saving of laws providing for acquisition of estates, etc
[[31B]]. Validation of certain Acts and Regulations
[[31C]]. Saving of laws giving effect to certain directive principles
[[31D]]. [Saving of laws in respect of anti-national activities.] Rep. by the Constitution (Forty-third Amendment) Act,1977, s.2 (w.e.f.13-4-1978).