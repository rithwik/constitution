[[32]]. Remedies for enforcement of rights conferred by this Part
[[32A]]. [Constitutional validity of State laws not to be considered in proceedings under article 32.] Rep. by the Constitution (Forty-third Amendment) Act, 1977, s. 3 (w.e.f. 13-4-1978).
[[33]]. Power of Parliament to modify the rights conferred by this Part in their application to Forces, etc.
[[34]]. Restriction on rights conferred by this Part while martial law is in force in any area
[[35]]. Legislation to give effect to the provisions of this Part