[[25]]. Freedom of conscience and free profession, practice and propagation of religion
[[26]]. Freedom to manage religious affairs
[[27]]. Freedom as to payment of taxes for promotion of any particular religion
[[28]]. Freedom as to attendance at religious instruction or religious worship in certain educational institutions