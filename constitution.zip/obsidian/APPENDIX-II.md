RE-STATEMENT, WITH REFERENCE TO THE PRESENT TEXT OF THE CONSTITUTION, OF THE EXCEPTIONS AND MODIFICATIONS SUBJECT TO WHICH THE CONSTITUTION APPLIES TO THE STATE OF JAMMU AND KASHMIR

[Note.— The exceptions and modifications subject to which the Constitution applies to the State of Jammu and Kashmir are either those provided in the Constitution (Application to Jammu and Kashmir) Order, 1954 or those consequential to the non-application to the State of Jammu and Kashmir of certain amendments to the Constitution. All the exceptions and modifications which have a practical significance are included in the re-statement which is only for facility of quick reference. For ascertaining the exact position, reference will have to be made to the Constitution (Application to Jammu and Kashmir) Order, 1954 and to the text of the Constitution on the 20th June, 1964, as amended by the subsequent amendments to the Constitution mentioned in clause 2 of the said Order.]

(1) THE PREAMBLE.

(a) In the first paragraph, omit "SOCIALIST SECULAR";

(b) in the penultimate paragraph, omit "and integrity".

(2) PART I.

Article [[3]].—

(a) Add the following further proviso, namely:—

"Provided further that no Bill providing for increasing or diminishing the area of the State of Jammu and Kashmir or altering the name or boundary of that State shall be introduced in Parliament without the consent of the Legislature of that State.";

(b) omit Explanation I and Explanation II.

(3) PART II.

(a) This Part shall be deemed to have been applicable in relation to the State of Jammu and Kashmir as from the 26th day of January, 1950.

(b) Article [[7]].— Add the following further proviso, namely:—

"Provided further that nothing in this article shall apply to a permanent resident of the State of Jammu and Kashmir who, after having so migrated to the territory now included in Pakistan, returns to that territory of that State under a permit for resettlement in that State or permanent return issued by or under the authority of any law made by the Legislature of that State, and every such person shall be deemed to be a citizen of India.".

(4) PART III.

(a) Article [[13]].—References to the commencement of the Constitution shall be construed as references to the commencement of the Constitution (Application to Jammu and Kashmir) Order, 1954 (C.O. 48), i.e., the 14th day of May, 1954.

(c) Article [[16]].— In clause (3), reference to the State shall be construed as not including a reference to the State of Jammu and Kashmir.

(d) Article [[19]].—

(A) In clause (1),—

(i) in sub-clause (e), omit "and" at the end;

(ii) after sub-clause (e), insert the following clause, namely:—

"(f) to acquire, hold and dispose of property; and";

(B) in clause (5), for "sub-clauses (d) and (e)", substitute "sub-clauses (d), (e) and (f)”.

(e) Article [[22]].— In clauses (4) and (7), for "Parliament", substitute "the Legislature of the State".

(f) Article [[30]].—Omit clause (1A).

(g) After article [[30]], insert the following, namely:—

"Right to Property

31. Compulsory acquisition of property.—(1) No person shall be deprived of his property save by authority of law.

(2) No property shall be compulsorily acquired or requisitioned save for a public purpose and save by authority of a law which provides for acquisition or requisitioning of the property for an amount which may be fixed by such law or which may be determined in accordance with such principles and given in such manner as may be specified in such law; and no such law shall be called in question in any court on the ground that the amount so fixed or determined is not adequate or that the whole or any part of such amount is to be given otherwise than in cash:

Provided that in making any law providing for the compulsory acquisition of any property of an educational institution established and administered by a minority, referred to in clause (1) of article 30, the State shall ensure that the amount fixed by or determined under such law for the acquisition of such property is such as would not restrict or abrogate the right guaranteed under that clause.

(2A) Where a law does not provide for the transfer of the ownership or right to possession of any property to the State or to a Corporation owned or controlled by the State, it shall not be deemed to provide for the compulsory acquisition or requisitioning of property, notwithstanding that it deprives any person of his property.

(2B) Nothing in sub-clause (f) of clause (1) of article [[19]] shall affect any such law as is referred to in clause (2).

(5) Nothing in clause 2 shall affect—

(a) the provisions of any existing law; or

(b) the provisions of any law which the State may hereafter make—

(i) for the purpose of imposing or levying any tax or penalty; or

(ii) for the promotion of public health or the prevention of danger to life or property; or

(iii) with respect to property declared by law to be evacuee property.".

(h) After article [[31]], omit the following sub-heading, namely:—

“Saving of Certain Laws”

(i) Article [[31A]].—

(A) In clause (1),—

(i) for "article 14 or article 19", substitute "article 14, article 19 or article 31";

(ii) omit the first proviso to clause (1);

(iii) in the second proviso omit "further";

(B) in clause (2), for sub-clause (a), substitute the following sub-clause, namely:—

'(a) "estate" shall mean land which is occupied or has been let for agricultural purposes or for purposes subservient to agriculture, or for pasture, and includes—

(i) sites of buildings and other structures on such land;

(ii) trees standing on such land;

(iii) forest land and wooded waste;

(iv) area covered by or fields floating over water;

(v) sites of jandars and gharats;

(vi) any jagir, inam, muafi or mukarrari or other similar grant,

but does not include—

(i) the site of any building in any town, or town area or village abadi or any land appurtenant to any such building or site;

(ii) any land which is occupied as the site of a town or village; or

(iii) any land reserved for building purposes in a municipality or notified area or cantonment or town area or any area for which a town planning scheme is sanctioned;'.

(j) Article [[31C]].— This article is not applicable to the State of Jammu and Kashmir.

(k) Article [[32]].— Omit clause (3).

(l) Article [[35]].—

(A) References to the commencement of the Constitution shall be construed as references to the commencement of the Constitution (Application to Jammu and Kashmir) Order, 1954 (C.O. 48), i.e., the 14th day of May, 1954;

(B) in clause (a) (i), omit "clause (3) of article 16, clause (3) of article 32";

(C) after clause ( ), add the following clause, namely:—

"(c) no law with respect to preventive detention made by the Legislature of the State of Jammu and Kashmir, whether before or after the commencement of the Constitution (Application to Jammu and Kashmir) Order, 1954, shall be void on the ground that it is inconsistent with any of the provisions of this Part, but any such law shall, to the extent of such inconsistency, cease to have effect on the expiration of twenty-five years from the commencement of the said Order, except as respects things done or omitted to be done before the expiration thereof.".

(m) After article 35, add the following article, namely:—

"35A. Saving of laws with respect to permanent residents and their rights.—Notwithstanding anything contained in this Constitution, no existing law in force in the State of Jammu and Kashmir, and no law hereafter enacted by the Legislature of the State,—

(a) defining the classes of persons who are, or shall be, permanent residents of the State of Jammu and Kashmir; or

(b) conferring on such permanent residents any special rights and privileges or imposing upon other persons any restrictions as respects—

(i) employment under the State Government;

(ii) acquisition of immovable property in the State;

(iii) settlement in the State; or

(iv) right to scholarships and such other forms of aid as the State Government may provide,

shall be void on the ground that it is inconsistent with or takes away or abridges any rights conferred on the other citizens of India by any provision of this Part.".

(5) PART IV.—This part is not applicable to the State of Jammu and Kashmir.

(6) PART IVA.—This part is not applicable to the State of Jammu and Kashmir.

(7) PART V.—

(a) Article [[55]].—

(A) For the purposes of this article, the population of the State of Jammu and Kashmir shall be deemed to be sixty-three lakhs;

(B) in the Explanation omit the proviso.

(b) Article [[81]].—For clauses (2) and (3), substitute the following clauses, namely:—

"(2) For the purposes of sub-clause (a) of clause (1),—

(a) there shall be allotted to the State six seats in the House of the People;

(b) the State shall be divided into single-member territorial constituencies by the Delimitation Commission constituted under the Delimitation Act, 1972, in accordance with such procedure as the Commission may deem fit;

(c) the constituencies shall, as far as practicable, be geographically compact areas, and in delimiting them regard shall be had to physical features, existing boundaries of administrative units, facilities of communication and public convenience; and

(d) the constituencies into which the State is divided shall not comprise the area under the occupation of Pakistan.

(3) Nothing in clause (2) shall affect the representation of the State in the House of the People until the dissolution of the House existing on the date of publication in the Gazette of India of the final order or orders of the Delimitation Commission relating to the delimitation of parliamentary constituencies under the Delimitation Act, 1972.

(4) (a) The Delimitation Commission shall associate with itself for the purpose of assisting it in its duties in respect of the State, five persons who shall be members of the House of the People representing the State.

(b) The persons to be so associated from the State shall be nominated by the Speaker of the House of the People having due regard to the composition of the House.

(c) The first nominations to be made under sub-clause (b) shall be made by the Speaker of the House of the People within two months from the commencement of the Constitution (Application to Jammu and Kashmir) Second Amendment Order, 1974.

(d) None of the associate members shall have a right to vote or to sign any decision of the Delimitation Commission.

(e) If owing to death or resignation, the office of an associate member falls vacant, it shall be filled as soon as may be practicable by the Speaker of the House of the People and in accordance with the provisions of sub-clauses (a) and (b).".

(c) Article [[82]].— Omit the second and third provisos.

(d) Article [[105]].— In clause (3), for "shall be those of that House and of its members and committees immediately before the coming into force of section 15 of the Constitution (Forty-fourth Amendment) Act, 1978" substitute "shall be those of the House of Commons of the Parliament of the United Kingdom, and of its members and committees, at the commencement of this Constitution".

(e) For article [[132]], substitute the following article, namely:—

'132. Appellate jurisdiction of Supreme Court in appeals from High Courts in certain cases.—(1) An appeal shall lie to the Supreme Court from any judgment, decree or final order of a High Court in the territory of India, whether in a civil, criminal or other proceeding, if the High Court certifies that the case involves a substantial question of law as to the interpretation of this Constitution.

(2) Where the High Court has refused to give such a certificate, the Supreme Court may, if it is satisfied that the case involves a substantial question of law as to the interpretation of this Constitution, grant special leave to appeal from such judgment, decree or final order.

(3) Where such a certificate is given, or such leave is granted, any party in the case may appeal to the Supreme Court on the ground that any such question as aforesaid has been wrongly decided and, with the leave of the Supreme Court, on any other ground.

Explanation.—For the purposes of this article, the expression "final order" includes an order deciding an issue which, if decided in favour of the appellant, would be sufficient for the final disposal of the case.'.

(f) Article [[133]].—

(A) In clause (1), omit "under article 134A";

(B) after clause (1), insert the following clause, namely:—

'(1A) The provisions of section 3 of the Constitution (Thirtieth Amendment) Act, 1972, shall apply in relation to the State of Jammu and Kashmir subject to the modification that references therein to "this Act", "the commencement of this Act", "this Act had not been passed" and "as amended by this Act" shall be construed respectively as references to "the Constitution (Application to Jammu and Kashmir) Second Amendment Order, 1974", "the commencement of the said Order", "the said Order had not been made" and "as it stands after the commencement of the said Order".'.

(g) Article [[134]].—

(A) In clause (1), in sub-clause (c), omit "under article 134A";

(B) in clause (2), after "Parliament may" insert "on the request of the Legislature of the State".

(h) Articles [[134A]], [[135]], [[139]] and [[139A]].— These articles are not applicable to the State of Jammu and Kashmir.

(i) Article [[145]].— In clause (1), omit sub-clause (cc).

(j) Article [[150]].— For "as the President may, on the advice of the Comptroller and Auditor-General of India, prescribe" substitute "as the Comptroller and Auditor-General of India may, with the approval of the President prescribe".

(8) PART VI.

(a) Omit articles [[153]] to [[217]], article [[219]], article [[221]], articles [[223]], [[224]], [[224A]] and [[225]], articles [[227]] to [[233]], article [[233A]] and articles [[234]] to [[237]].

(b) Article [[220]].— References to the commencement of the Constitution shall be construed as references to the commencement of the Constitution (Application to Jammu and Kashmir) Amendment Order, 1960, i.e., the 26th January, 1960.

(c) Article [[222]].— After clause (1), insert the following clause, namely:—

"(1A) Every such transfer from the High Court of Jammu and Kashmir or to that High Court shall be made after consultation with the Governor.".

(d) Article [[226]].—

(A) Renumber clause (2) as clause (1A);

(B) omit clause (3);

(C) renumber clause (4) as clause (2); and in clause (2) as so renumbered, for "this article" substitute "clause (1) or clause (1A)".

(9) PART VIII.— This part is not applicable to the State of Jammu and Kashmir.

(10) PART X.— This part is not applicable to the State of Jammu and Kashmir.

(11) PART XI.

(a) Article [[246]].—

(A) in clause (1), for "clauses (2) and (3)" substitute "clause (2)";

(B) in clause (2), omit "Notwithstanding anything in clause (3),";

(C) omit clauses (3) and (4).

(b) For article [[248]], substitute the following article, namely:—

'248. Residuary powers of legislation.—Parliament has exclusive power to make any law with respect to—

(a) prevention of activities involving terrorist acts directed towards overawing the Government as by law established or striking terror in the people or any section of the people or alienating any section of the people or adversely affecting the harmony amongst different sections of the people;

(aa) prevention of other activities directed towards disclaiming, questioning or disrupting the sovereignty and territorial integrity of India or bringing about cession of a part of the territory of India or secession of a part of the territory of India from the Union or causing insult to the Indian National Flag, the Indian National Anthem and this Constitution; and

(b) taxes on—

(i) foreign travel by sea or air;

(ii) inland air travel;

(iii) postal articles, including money orders, phonograms and telegrams.

Explanation.— In this article, "terrorist act" means any act or thing by using bombs, dynamite or other explosive substances or inflammable substances or firearms or other lethal weapons or poisons or noxious gases or other chemicals or any other substances (whether biological or otherwise) of a hazardous nature.'.

(bb) Article [[249]], in clause (1), for "any matter enumerated in the State List specified in the resolution", substitute "any matter specified in the resolution, being a matter which is not enumerated in the Union List or in the Concurrent List".

(c) Article [[250]].— For "to any of the matters enumerated in the State List" substitute "also to matters not enumerated in the Union List".

(d) Omit clause (d).

(e) Article [[253]].— Add the following proviso, namely:—

"Provided that after the commencement of the Constitution (Application to Jammu and Kashmir) Order, 1954, no decision affecting the disposition of the State of Jammu and Kashmir shall be made by the Government of India without the consent of the Government of that State.".

(f) Omit article [[255]].

(g) Article [[256]].—Renumber this article as clause (1) thereof, and add the following new clause thereto, namely:—

"(2) The State of Jammu and Kashmir shall so exercise its executive power as to facilitate the discharge by the Union of its duties and responsibilities under the Constitution in relation to that State; and in particular, the said State shall, if so required by the Union, acquire or requisition property on behalf and at the expense of the Union, or if the property belongs to the State, transfer it to the Union on such terms as may be agreed, or in default of agreement, as may be determined by an arbitrator appointed by the Chief Justice of India.".

(h) Article [[261]].—In clause (2), omit "made by Parliament".

(12) PART XII.

(a) Articles [[266]], [[282]], [[284]], [[298]], [[299]] and [[300]]. —In these articles references to the State or States shall be construed as not including references to the State of Jammu and Kashmir;

(b) omit clause (2) of article [[267]], article [[273]], clause (2) of article [[283]] and article [[290]];

(c) Articles [[277]] and [[295]].—In these articles references to the commencement of the Constitution shall be construed as references to the commencement of the Constitution (Application to Jammu and Kashmir) Order, 1954, i.e., the 14th day of May, 1954.

(d) Omit the sub-heading "CHAPTER IV.— RIGHT TO PROPERTY" and article [[300A]].

(13) PART XIII.

In article [[303]], in clause (1), omit "by virtue of any entry relating to trade and commerce in any of the Lists in the Seventh Schedule".

(14) PART XIV.

Except in article [[312]], reference to "State" in this Part does not include the State of Jammu and Kashmir.

(15) PART XIVA.

This Part is not applicable to the State of Jammu and Kashmir.

(16) PART XV.—

(a) Article [[324]].— In clause (1), the reference to the Constitution shall, in relation to elections to either House of the Legislature of Jammu and Kashmir, be construed as a reference to the Constitution of Jammu and Kashmir.

(b) Articles [[325]], [[326]] and [[327]].— In these articles the references to a State shall be construed as not including a reference to the State of Jammu and Kashmir.

(c) Omit article [[328]].

(d) Article [[329]].—

(A) Reference to a State shall be construed as not including a reference to the State of Jammu and Kashmir;

(B) omit "or article 328".

(17) PART XVI. —

Original clause (a) omitted and clauses (b) and (c) relettered as clauses (a) and (b).

(a) Omit articles [[331]], [[332]], [[333]], [[336]] and [[337]].

(b) Articles [[334]] and [[335]].—References to the State or the States shall be construed as not including references to the State of Jammu and Kashmir.

(c) Article [[339]], in clause (1), omit “the administration of the Scheduled Areas and”.

(18) PART XVII. — The provisions of this Part shall apply to the State of Jammu and Kashmir only in so far as they relate to—

(i) The official language of the Union;

(ii) the official language for communication between one State and another, or between a State and the Union; and

(iii) The language of the proceedings in the Supreme Court.

(19) PART XVIII.

(a) For article [[352]], substitute the following article, namely :—

“352. Proclamation of Emergency.—(1) If the President is satisfied that a grave emergency exists whereby the security of India or of any part of the territory thereof is threatened, whether by war or external aggression or internal disturbance, he may, by Proclamation, make a declaration to that effect.

(2) A proclamation issued under clause (1)—

(a) may be revoked by a subsequent Proclamation;

(b) shall be laid before each House of Parliament;

(c) shall cease to operate at the expiration of two months unless before the expiration of that period it has been approved by resolutions of both Houses of Parliament:

Provided that if any such Proclamation is issued at a time when the House of the People has been dissolved or the dissolution of the House of the People takes place during the period of two months referred to in sub-clause (c), and if a resolution approving the Proclamation has been passed by the Council of States but no resolution with respect to such Proclamation has been passed by the House of the People before the expiration of that period, the Proclamation shall cease to operate at the expiration of thirty days from the date on which the House of the People first sits after its reconstitution unless before the expiration of the said period of thirty days a resolution approving the Proclamation has been also passed by the House of the people.

(3) A Proclamation of Emergency declaring that the security of India or of any part of the territory thereof is threatened by war or by external aggression or by internal disturbance may be made before the actual occurrence of war or of any such aggression or disturbance if the President is satisfied that there is imminent danger thereof.

(4) The power conferred on the President by this article shall include the power to issue different Proclamations on different grounds, being war or external aggression or internal disturbance or imminent danger of war or external aggression or internal disturbance, whether or not there is a Proclamation already issued by the President under clause (1) and such Proclamation is in operation.

(5) Notwithstanding anything in the Constitution,—

(a) the satisfaction of the President mentioned in clause (1) and clause (3) shall be final and conclusive and shall not be questioned in any court on any ground;

(b) subject to the provisions of clause (2), neither the Supreme Court nor any other Court shall have jurisdiction to entertain any question, on any ground, regarding the validity of —

(i) a declaration made by Proclamation by the President to the effect stated in clause (1); or

(ii) the continued operation of such Proclamation.

(6) No Proclamation of Emergency made on grounds only of internal disturbance or imminent danger thereof shall have effect in relation to the State of Jammu and Kashmir (except as respects article [[354]]) unless—

(a) it is made at the request or with the concurrence of the Government of that State; or

(b) where it has not been so made, it is applied subsequently by the President to that State at the request or with the concurrence of the Government of that State.”.

(b) Article [[353]].— Omit the proviso.

(c) Article [[356]].—

(A) In clause (1), reference to provisions or provisions of this Constitution shall, in relation to the State of Jammu and Kashmir, be construed as including references to provisions or provision of the Constitution of Jammu and Kashmir;

(B) in clause (4),—

(i) for the opening portion, substitute the following, namely:—

“A Proclamation so approved shall, unless revoked, cease to operate on the expiration of a period of six months from the date of the passing of the second of the resolutions approving the Proclamation under clause (3)”;

(ii) after the second proviso, the following proviso shall be inserted, namely :—

‘Provided also that in the case of the Proclamation issued under clause (1) on the 18th day of July, 1990 with respect to the State of Jammu and Kashmir, the reference in the fist proviso to this clause to “three years” shall be construed as a reference to “seven years.’.

(C) for clause (5), substitute the following clause, namely :—

“(5) Notwithstanding anything in this Constitution, the satisfaction of the President mentioned in clause (1) shall be final and conclusive and shall not be questioned in any court on any ground.”.

(d) Article [[357]].— For clause (2), substitute the following clause, namely :—

“(2) Any law made in exercise of the power of the Legislature of the State by Parliament or the President or other authority referred to in sub-clause (a) of clause (1) which Parliament or the President or such other authority would not, but for the issue of a Proclamation under article [[356]], have been competent to make shall, to the extent of the incompetency, cease to have effect on the expiration of a period of one year after the Proclamation has ceased to operate except as respects things done or omitted to be done before the expiration of the said period, unless the provisions which shall so cease to have effect are sooner repealed or re-enacted with or without modification by Act of the appropriate Legislature.”.

(e) For article [[358]], substitute the following article, namely :—

“358. Suspension of provisions of article [[19]] during emergencies.— While a Proclamation of Emergency is in operation, nothing in article 19 shall restrict the power of the State as defined in Part III to make any law or to take any executive action which the State would but for the provisions contained in that Part be competent to make or to take, but any law so made shall, to the extent of the incompetency, cease to have effect as soon as the Proclamation ceases to operate, except as respects things done or omitted to be done before the law so ceases to have effect.”.

(f) Article [[359]], —

(A) in clause (1) omit “(except articles 20 and 21)”;

(B) in clause (1A),—

(i) omit “(except articles 20 and 21)”;

(ii) omit the proviso;

(C) omit clause (1B);

(D) in clause (2), omit the proviso.

(g) omit article [[360]].

(20) PART XIX.

(a) Article [[361A]].— This article is not applicable to the State of Jammu and Kashmir.

(b) Omit article [[365]].

(c) Article [[367]].— After clause (3), add the following clause, namely :—

“(4) For the purposes of this Constitution as it applies in relation to the State of Jammu and Kashmir —

(a) references to this Constitution or to the provisions thereof shall be construed as references to the Constitution or the provisions thereof as applied in relation to the said State;

(aa) references to the person for the time being recognised by the President on the recommendation of the Legislative Assembly of the State as the Sadar-i-Riyasat of Jammu and Kashmir, acting on the advice of the Council of Ministers of the State for the time being in office, shall be construed as references to the Governor of Jammu and Kashmir;

(b) references to the Government of the said State shall be construed as including references to the Governor of Jammu and Kashmir acting on the advice of his Council of Ministers:

Provided that in respect of any period prior to the 10th day of April, 1965, such references shall be construed as including references to the Sadar-i-Riyasat acting on the advice of his Council of Ministers;

(c) references to a High Court shall include references to the High Court of Jammu and Kashmir;

(d) references to the permanent residents of the said State shall be construed as meaning persons who, before the commencement of the Constitution (Application to Jammu and Kashmir) Order, 1954, were recognised as State subjects under the laws in force in the State or who are recognised by any law made by the Legislature of the State as permanent residents of the State; and

(e) references to a Governor shall include references to the Governor of Jammu and Kashmir :

Provided that in respect of any period prior to the 10th day of April, 1965, such references shall be construed as references to the person recognised by the President as the Sadar-i-Riyasat of Jammu and Kashmir and as including references to any person recognised by the President as being competent to exercise the powers of the Sadar-I-Riyasat.

(21) PART XX.

Article [[368]].—

(a) in clause (2), add the following further proviso, namely:—

“Provided further that no such amendment shall have effect in relation to the State of Jammu and Kashmir unless applied by order of the President under clause (1) of article [[370]].”;

(b) omit clauses (4) and (5) and after clause (3) add the following clause, namely :—

“(4) No law made by the Legislature of the State of Jammu and Kashmir seeking to make any change in or in the effect of any provision of the Constitution of Jammu and Kashmir relating to:—

(a) appointment, powers, functions, duties, emoluments, allowances, privileges or immunities of the Governor; or

(b) superintendence, direction and control of elections by the Election Commission of India, eligibility for inclusion in the electoral rolls without discrimination, adult suffrage and composition of the Legislative Council, being matters specified in sections 138, 139, 140 and 50 of the Constitution of Jammu and Kashmir,

shall have any effect unless such law has, after having been reserved for the consideration of the President, received his assent.”.

(22) PART XXI.—

(a) Omit articles [[369]], [[371]], [[371A]], [[372A]], [[373]] and articles [[376]] to [[378A]] and [[392]].

(b) Article [[372]].—

(A) Omit clauses (2) and (3) ;

(B) references to the laws in force in the territory of India shall include references to hidayats, ailans, ishtihars, circulars, robkars, irshads, yadashts, State Council Resolutions, Resolutions of the Constituent Assembly, and other instruments having the force of law in the territory of the State of Jammu and Kashmir;

(C) references to the commencement of the Constitution shall be construed as references to the commencement of the Constitution (Application to Jammu and Kashmir) Order, 1954 (C.O.48), i.e., the 14th day of May, 1954.

(c) Article [[374]]. —

(A) Omit clauses (1), (2), (3) and (5);

(B) in clause (4), the reference to the authority functioning as the Privy Council of a State shall be construed as a reference to the Advisory Board constituted under the Jammu and Kashmir Constitution Act, Svt. 1996, and references to the commencement of the Constitution shall be construed as references to the commencement of the Constitution (Application to Jammu and Kashmir) Order, 1954, i.e., the 14th day of May, 1954.

(23) PART XXII.—Omit articles [[394]] and [[395]].

(24) THIRD SCHEDULE.—Omit forms V,VI,VII and VIII.

(25) FIFTH SCHEDULE.—This Schedule is not applicable to the State of Jammu and Kashmir,

(26) SIXTH SCHEDULE.—This Schedule is not applicable to the State of Jammu and Kashmir.

(27) SEVENTH SCHEDULE.—

(a) List I —Union List:—

(A) Omit entry 2A;

(B) for entry 3, substitute the following entry, namely :—

“3. Administration of cantonments.”:

(C) omit entries 8, 9, 34 and 79;

(D) in entry 72, the reference to the States shall be construed.—

(i) in relation to appeals to the Supreme Court from any decision or order of the High Court of the State of Jammu and Kashmir made in an election petition whereby an election to either House of the Legislature of that State has been called in question, as including a reference to the State of Jammu and Kashmir;

(ii) in relation to other matters, as not including a reference to that State;

(E) in entry 81, omit “Inter-State migration”;

(F) for entry 97, substitute the following entry, namely :—

‘97. Prevention of activities—

(a) involving terrorist acts directed towards overawing the Government as by law established or striking terror in the people or any section of the people or alienating any section of the people or adversely affecting the harmony amongst different sections of the people;

(b) directed towards disclaiming, questioning or disrupting the sovereignty and territorial integrity of India or bringing about cession of a part of the territory of India or secession of a part of the territory of India from the Union or causing insult to the Indian National flag, the Indian National Anthem and this Constitution;

taxes on foreign travel by sea or air, on inland air travel and on postal articles, including money orders, phonograms and telegrams.

Explanation.— In this entry, “terrorist act” has the same meaning as in the Explanation to article [[248]].’.

(b) Omit List II—State List.

(c) List III— Concurrent List.—

(A) For entry 1, substitute the following entry, namely :—

“1. Criminal law (excluding offences against laws with respect to any of the matters specified in List I and excluding the use of naval, military or air forces or any other armed forces of the Union in aid of the civil power) in so far as such criminal law relates to offences against laws with respect to any of the matters specified in this List.”;

(B) for entry 2, substitute the following entry, namely:—

“2. Criminal procedure (including prevention of offences and constitution and organisation of criminal courts, except the Supreme Court and the High Court) in so far as it relates to,—

(i) offences against laws with respect to any matters being matters with respect to which Parliament has power to make laws; and

(ii) administration of oaths and taking of affidavits by diplomatic and consular officers in any foreign country.”;

(C) omit entry 3, entries 5 to 10 (both inclusive), entries 14, 15, 17, 20, 24, 27, 28, 29, 31, 32, 37, 38, 41 and 44;

(D) entries 11A, 17A, 17B, 20A and 33A are not applicable to the State of Jammu and Kashmir;

( E) for entry 12, substitute the following entry, namely :—

“12. Evidence and oaths in so far as they relate to,—

(i) administration of oaths and taking of affidavits by diplomatic and consular officers in any foreign country; and

(ii) any other matter being matters with respect to which Parliament has power to make laws.”;

(F) for entry 13, substitute the following entry, namely :—

“13. Civil procedure in so far as it relates to administration of oaths and taking of affidavits by diplomatic and consular officers in any foreign country.”;

(G) for entry 25, substitute the following entry, namely :—

“25. Vocational and technical training of labour.”;

(H) for entry 30, substitute the following entry, namely:—

“30. Vital statistics in so far as they relate to births and deaths including registration of births and deaths.”;

(I) for entry 42, substitute the following entry, namely:—

“42 Acquisition and requisitioning of property, so far as regards acquisition of any property covered by entry 67 of List I or entry 40 of List III or of any human work of art which has artistic or aesthetic value.”;

(J) in entry 45, for “List II or List III” substitute “this List”.

(28) NINTH SCHEDULE.—

(a) After entry 64, add the following entries, namely :—

“64A. The Jammu and Kashmir State Kuth Act (No. 1 of Svt.1978).

64B. The Jammu and Kashmir Tenancy Act (No. II of Svt. 1980).

64C. The Jammu and Kashmir Alienation of Land Act (No. V of Svt. 1995). 64D. The Jammu and Kashmir Big Landed Estates Abolition Act (No. XVII of Svt. 2007).

64E. Order No. 6-H of 1951, dated the 10th March, 1951, regarding Resumption of Jagirs and other assignments of land revenue, etc.

64F. The Jammu and Kashmir Restitution of Mortgaged Properties Act, 1976 (Act XIV of 1976).

64G. The Jammu and Kashmir Debtors’ Relief Act, 1976 (Act XV of 1976).”.

(b) entries 65 to 86 are not applicable to the State of Jammu and Kashmir;

(c) after entry 86, insert the following entry, namely:—

“87. The Representation of the People Act, 1951 (Central Act 43 of 1951), the Representation of the People (Amendment) Act, 1974 (Central Act 58 of 1974) and the Election Laws (Amendment) Act, 1975 (Central Act 40 of 1975).”;

(d) after entry 91, insert the following entry, namely:—

“92. The maintenance of Internal Security Act, 1971 (Central Act 26 of 1971).”;

(e) after entry 129, insert the following entry, namely :—

“130. The Prevention of Publication of Objectionable Matter Act, 1976 (Central Act 27 of 1976).”;

(f) after insertion of the entries 87, 92 and 130 as indicated above, renumber entries 87 to 188 as entries 65 to 166 respectively.

(29) [[TENTH SCHEDULE]].—

(a) for the brackets, words and figures “[Articles 102(2) and 191(2)]”, the brackets, word and figures “[Article 102(2)]” shall be substituted;

(b) in clause (a) of paragraph 1, the words “or the Legislative Assembly or, as the case may be, either House of the Legislature of a State” shall be omitted;

(c) in paragraph 2,—

(i) in sub-paragraph (1), in sub-clause (ii) of clause (b) of the Explanation, the words and figures “or, as the case may be, article 188” shall be omitted;

(ii) in sub-paragraph (3), the words and figures “or, as the case may be, article 188” shall be omitted;

(iii) in sub-paragraph (4), the reference to the commencement of the Constitution (Fifty-second Amendment) Act, 1985 shall be construed as a reference to the commencement of the Constitution (Application to Jammu and Kashmir) Amendment Order, 1989;

(d) in paragraph 5, the words “or the Chairman or the Deputy Chairman of the Legislative Council of a State or the Speaker or the Deputy Speaker of the Legislative Assembly of a State” shall be omitted;

(e) in sub-paragraph (2) of paragraph 6, the words and figures “or, as the case may be, proceedings in the Legislature of a State within the meaning of article 212” shall be omitted;

(f) in sub-paragraph (3) of paragraph 8, the words and figures “or, as the case may be, article 194,” shall be omitted.