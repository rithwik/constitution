## CHAPTER I - LANGUAGE OF THE UNION
[[343]]. Official language of the Union
[[344]]. Commission and Committee of Parliament on official language

## CHAPTER II - REGIONAL LANGUAGES
[[345]]. Official language or languages of a State
[[346]]. Official language for communication between one State and another or between a State and the Union
[[347]]. Special provision relating to language spoken by a section of the population of a State 

## CHAPTER III - LANGUAGE OF THE SUPREME COURT, HIGH COURTS, ETC.
[[348]]. Language to be used in the Supreme Court and in the High Courts and for Acts, Bills, etc.
[[349]]. Special procedure for enactment of certain laws relating to language
 
## CHAPTER IV - SPECIAL DIRECTIVES
[[350]]. Language to be used in representations for redress of grievances
[[350A]]. Facilities for instruction in mother-tongue at primary stage
[[350B]]. Special Officer for linguistic minorities
[[351]]. Directive for development of the Hindi language