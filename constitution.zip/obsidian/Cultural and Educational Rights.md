[[29]]. Protection of interests of minorities
[[30]]. Right of minorities to establish and administer educational institutions
[[31]]. [Compulsory acquisition of property.] Rep. by the Constitution (Forty-fourth Amendment) Act, 1978, s. 6 (w.e.f. 20-6-1979).

