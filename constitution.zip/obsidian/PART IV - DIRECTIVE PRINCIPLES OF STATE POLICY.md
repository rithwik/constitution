[[36]]. Definition
[[37]]. Application of the principles contained in this Part
[[38]]. State to secure a social order for the promotion of welfare of the people
[[39]]. Certain principles of policy to be followed by the State
[[39A]]. Equal justice and free legal aid
[[40]]. Organisation of village panchayats
[[41]]. Right to work, to education and to public assistance in certain cases
[[42]]. Provision for just and humane conditions of work and maternity relief
[[43]]. Living wage, etc., for workers
[[43A]]. Participation of workers in management of industries
[[44]]. Uniform civil code for the citizens
[[45]]. Provision for free and compulsory education for children
[[46]]. Promotion of educational and economic interests of Scheduled Castes, Scheduled Tribes and other weaker sections
[[47]]. Duty of the State to raise the level of nutrition and the standard of living and to improve public health
[[48]]. Organisation of agriculture and animal husbandry
[[48A]]. Protection and improvement of environment and safeguarding of forests and wild life
[[49]]. Protection of monuments and places and objects of national importance
[[50]]. Separation of judiciary from executive
[[51]]. Promotion of international peace and security