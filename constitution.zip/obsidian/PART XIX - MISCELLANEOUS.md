[[361]]. Protection of President and Governors and Rajpramukhs
[[361A]]. Protection of publication of proceedings of Parliament and State Legislatures
[[361B]]. Disqualification for appointment on remunerative political post
[[362]]. [Rights and privileges of Rulers of Indian States.] Rep. by the Constitution (Twenty-sixth Amendment) Act, 1971, s. 2.
[[363]]. Bar to interference by courts in disputes arising out of certain treaties, agreements, etc
[[363A]]. Recognition granted to Rulers of Indian States to cease and privy purses to be abolished.—Notwithstanding anything in this Constitution or in any law for the time being in force
[[364]]. Special provisions as to major ports and aerodromes
[[365]]. Effect of failure to comply with, or to give effect to, directions given by the Union
[[366]]. Definitions
[[367]]. Interpretation