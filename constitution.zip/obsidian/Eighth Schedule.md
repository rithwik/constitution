EIGHTH SCHEDULE
Articles [[344]] (1) and [[351]]

Languages

1. Assamese.

2. Bengali.

3. Bodo.

4. Dogri.

5. Gujarati.

6. Hindi.

7. Kannada.

8. Kashmiri.

9. Konkani.

10. Maithili.

11. Malayalam.

12. Manipuri.

13. Marathi.

14. Nepali.

15. Oriya.

16. Punjabi.

17. Sanskrit.

18. Santhali.

19. Sindhi.

20. Tamil.

21. Telugu.

22. Urdu.