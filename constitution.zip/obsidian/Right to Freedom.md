[[19]]. Protection of certain rights regarding freedom of speech, etc
[[20]]. Protection in respect of conviction for offences
[[21]]. Protection of life and personal liberty
[[22]]. Protection against arrest and detention in certain cases