[[330]]. Reservation of seats for Scheduled Castes and Scheduled Tribes in the House of the People
[[331]]. Representation of the Anglo-Indian Community in the House of the People
[[332]]. Reservation of seats for Scheduled Castes and Scheduled Tribes in the Legislative Assemblies of the States
[[333]]. Representation of the Anglo-Indian community in the Legislative Assemblies of the States
[[334]]. Reservation of seats and special representation to cease after sixty years
[[335]]. Claims of Scheduled Castes and Scheduled Tribes to services and posts
[[336]]. Special provision for Anglo-Indian community in certain services
[[337]]. Special provision with respect to educational grants for the benefit of Anglo-Indian community
[[338]]. National Commission for Scheduled Castes
[[339]]. Control of the Union over the administration of Scheduled Areas and the welfare of Scheduled Tribes
[[340]]. Appointment of a Commission to investigate the conditions of backward classes
[[341]]. Scheduled Castes
[[342]]. Scheduled Tribes