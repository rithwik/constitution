TWELFTH SCHEDULE
Article [[243W]]

1. Urban planning including town planning.

2. Regulation of land-use and construction of buildings.

3. Planning for economic and social development.

4. Roads and bridges.

5. Water supply for domestic, industrial and commercial purposes.

6. Public health, sanitation conservancy and solid waste management.

7. Fire services.

8. Urban forestry, protection of the environment and promotion of ecological aspects.

9. Safeguarding the interests of weaker sections of society, including the handicapped and mentally retarded.

10. Slum improvement and upgradation.

11. Urban poverty alleviation.

12. Provision of urban amenities and facilities such as parks, gardens, playgrounds.

13. Promotion of cultural, educational and aesthetic aspects.

14. Burials and burial grounds; cremations, cremation grounds; and electric crematoriums.

15. Cattle pounds; prevention of cruelty to animals.

16. Vital statistics including registration of births and deaths.

17. Public amenities including street lighting, parking lots, bus stops and public conveniences.

18. Regulation of slaughter houses and tanneries.