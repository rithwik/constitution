[[393]]. Short title
[[394]]. Commencement
[[394A]]. Authoritative text in the Hindi language
[[395]]. Repeals