[[243P]]. Definitions
[[243Q]]. Constitution of Municipalities
[[243R]]. Composition of Municipalities
[[243S]]. Constitution and composition of Wards Committees, etc.
[[243T]]. Reservation of seats
[[243U]]. Duration of Municipalities, etc.
[[243V]]. Disqualifications for membership
[[243W]]. Powers, authority and responsibilities of Municipalities, etc.
[[243X]]. Power to impose taxes by, and Funds of, the Municipalities.
[[243Y]]. Finance Commission
[[243Z]]. Audit of accounts of Municipalities