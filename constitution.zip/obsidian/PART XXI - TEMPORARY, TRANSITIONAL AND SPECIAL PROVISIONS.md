[[369]]. Temporary power to Parliament to make laws with respect to certain matters in the State List as if they were matters in the Concurrent List
[[370]]. Temporary provisions with respect to the State of Jammu and Kashmir
[[371]]. Special provision with respect to the States of Maharashtra and Gujarat
[[371A]]. Special provision with respect to the State of Nagaland
[[371B]]. Special provision with respect to the State of Assam
[[371C]]. Special provision with respect to the State of Manipur
[[371D]]. Special provisions with respect to the State of Andhra Pradesh
[[371E]]. Establishment of Central University in Andhra Pradesh
[[371F]]. Special provisions with respect to the State of Sikkim
[[371G]]. Special provision with respect to the State of Mizoram
[[371H]]. Special provision with respect to the State of Arunachal Pradesh
[[371-I]]. Special provision with respect to the State of Goa
[[372]]. Continuance in force of existing laws and their adaptation
[[372A]]. Power of the President to adapt laws
[[373]]. Power of President to make order in respect of persons under preventive detention in certain cases
[[374]]. Provisions as to Judges of the Federal Court and proceedings pending in the Federal Court or before His Majesty in Council
[[375]]. Courts, authorities and officers to continue to function subject to the provisions of the Constitution
[[376]]. Provisions as to Judges of High Courts
[[377]]. Provisions as to Comptroller and Auditor-General of India
[[378]]. Provisions as to Public Service Commissions
[[378A]]. Special provision as to duration of Andhra Pradesh Legislative Assembly
[[379]].—391. Rep. by the Constitution (Seventh Amendment) Act, 1956, s. 29 and Sch.
[[392]]. Power of the President to remove difficulties