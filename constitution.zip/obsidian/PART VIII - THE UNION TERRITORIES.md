[[239]]. Administration of Union territories
[[239A]]. Creation of local Legislatures or Council of Ministers or both for certain Union territories
[[239B]]. Power of administrator to promulgate Ordinances during recess of Legislature
[[240]]. Power of President to make regulations for certain Union territories
[[241]]. High Courts for Union territories
[[242]]. [Coorg.] Rep. by the Constitution (Seventh Amendment) Act, 1956, s. 29 and Sch.