[[14]]. Equality before law
[[15]]. Prohibition of discrimination on grounds of religion, race, caste, sex or place of birth
[[16]]. Equality of opportunity in matters of public employment
[[17]]. Abolition of Untouchability
[[18]]. Abolition of titles