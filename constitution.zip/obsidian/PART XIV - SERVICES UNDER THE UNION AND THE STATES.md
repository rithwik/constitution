## CHAPTER I - SERVICES
[[308]]. Interpretation
[[309]]. Recruitment and conditions of service of persons serving the Union or a State
[[310]]. Tenure of office of persons serving the Union or a State
[[311]]. Dismissal, removal or reduction in rank of persons employed in civil capacities under the Union or a State
[[312]]. All-India services
[[312A]]. Power of Parliament to vary or revoke conditions of service of officers of certain services
[[313]]. Transitional provisions
[[314]]. [Provision for protection of existing officers of certain services.] Rep. by the Constitution (Twenty-eighth Amendment) Act, 1972, s. 3 (w.e.f. 29-8-1972).


## CHAPTER II - PUBLIC SERVICE COMMISSIONS
[[315]]. Public Service Commissions for the Union and for the States
[[316]]. Appointment and term of office of members
[[317]]. Removal and suspension of a member of a Public Service Commission
[[318]]. Power to make regulations as to conditions of service of members and staff of the Commission
[[319]]. Prohibition as to the holding of offices by members of Commission on ceasing to be such members
[[320]]. Functions of Public Service Commissions
[[321]]. Power to extend functions of Public Service Commissions
[[322]]. Expenses of Public Service Commissions
[[323]]. Reports of Public Service Commissions