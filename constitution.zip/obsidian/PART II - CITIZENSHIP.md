[[5]]. Citizenship at the commencement of the Constitution
[[6]]. Rights of citizenship of certain persons who have migrated to India from Pakistan
[[7]]. Rights of citizenship of certain migrants to Pakistan
[[8]]. Rights of citizenship of certain persons of Indian origin residing outside India
[[9]]. Persons voluntarily acquiring citizenship of a foreign State not to be citizens
[[10]]. Continuance of the rights of citizenship
[[11]]. Parliament to regulate the right of citizenship by law