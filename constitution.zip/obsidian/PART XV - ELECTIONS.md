[[324]]. Superintendence, direction and control of elections to be vested in an Election Commission
[[325]]. No person to be ineligible for inclusion in, or to claim to be included in a special, electoral roll on grounds of religion, race, caste or sex
[[326]]. Elections to the House of the People and to the Legislative Assemblies of States to be on the basis of adult suffrage
[[327]]. Power of Parliament to make provision with respect to elections to Legislatures
[[328]]. Power of Legislature of a State to make provision with respect to elections to such Legislature
[[329]]. Bar to interference by courts in electoral matters
[[329A]]. [Special provision as to elections to Parliament in the case of Prime Minister and Speaker.] Rep. by the Constitution (Forty-fourth Amendment) Act, 1978, s. 36 (w.e.f. 20-6-1979).