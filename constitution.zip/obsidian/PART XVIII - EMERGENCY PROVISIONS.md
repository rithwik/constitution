[[352]]. Proclamation of Emergency
[[353]]. Effect of Proclamation of Emergency
[[354]]. Application of provisions relating to distribution of revenues while a Proclamation of Emergency is in operation
[[355]]. Duty of the Union to protect States against external aggression and internal disturbance
[[356]]. Provisions in case of failure of constitutional machinery in States
[[357]]. Exercise of legislative powers under Proclamation issued under article 356
[[358]]. Suspension of provisions of article 19 during emergencies
[[359]]. Suspension of the enforcement of the rights conferred by Part III during emergencies
[[359A]]. [Application of this Part to the State of Punjab.] Rep. by the Constitution (Sixty-third Amendment) Act, 1989, s. 3 (w.e.f. 6-1-1990).
[[360]]. Provisions as to financial emergency