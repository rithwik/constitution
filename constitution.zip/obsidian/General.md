[[12]]. Definition
[[13]]. Laws inconsistent with or in derogation of the fundamental rights